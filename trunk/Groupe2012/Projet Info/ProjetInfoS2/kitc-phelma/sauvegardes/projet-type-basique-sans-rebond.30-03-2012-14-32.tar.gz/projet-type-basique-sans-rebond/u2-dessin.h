// u2-dessin.h
// Sentinelle d'inclusion
#ifndef _u2_dessin_h
#define _u2_dessin_h

// Declaration des sous-programmes
void ZoneDessinDessinerCB( Fl_Widget* widget, void* data ) ;

#endif // _u2_dessin_h
